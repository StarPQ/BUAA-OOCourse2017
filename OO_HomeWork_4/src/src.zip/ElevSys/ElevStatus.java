package ElevSys;

public enum ElevStatus {
	UP, DOWN, STILL
}
