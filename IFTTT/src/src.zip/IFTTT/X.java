package IFTTT;

public enum X {
	RENAMED, MODIFIED, PATHCHANGED, SIZECHANGED
	
	
}
