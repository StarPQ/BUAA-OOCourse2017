package IFTTT;

public enum  Y {
	 RECORDSUM, RECORDDET, RECOVER
}
